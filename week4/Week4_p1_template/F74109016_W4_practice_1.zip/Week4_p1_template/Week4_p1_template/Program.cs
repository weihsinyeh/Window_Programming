﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week4_p1_template
{
    class Program
    {
        struct card
        {
            public string flower;
            public string num;
        }
        static int Count_point(card[] player_array)
        {
            //計算玩家目前的點數
            int player_point = 0;
            for (int i = 0; i < player_array.Length; i++)
            {
                switch (player_array[i].num)
                {
                    case "1":
                        player_point += 1;
                        break;
                    case "2":
                        player_point += 2;
                        break;
                    case "3":
                        player_point += 3;
                        break;
                    case "4":
                        player_point += 4;
                        break;
                    case "5":
                        player_point += 5;
                        break;
                    case "6":
                        player_point += 6;
                        break;
                    case "7":
                        player_point += 7;
                        break;
                    case "8":
                        player_point += 8;
                        break;
                    case "9":
                        player_point += 9;
                        break;
                    case "10":
                    case "J":
                    case "Q":
                    case "K":
                        player_point += 10;
                        break;
                }
            }
            if ((player_point <= 11) && ((player_array[0].num == "1") || (player_array[1].num == "1")))
            {
                player_point += 10; //有出現一點且兩張卡加起來不超過21
            }
            return player_point;
        }
        static void Main(string[] args)
        {
            try
            {
                // 程式流程
                // 1. 輸入玩家1、玩家2初始金錢(需要格式檢查)
                //
                Console.WriteLine("玩家1初始金錢: ");
                int player1_money = int.Parse(Console.ReadLine());

                if (player1_money == 0)
                {
                    Console.WriteLine("金錢不能為零，請重新輸入!");
                }
                Console.WriteLine("玩家2初始金錢: ");
                int player2_money = int.Parse(Console.ReadLine());

                // 2. 顯示玩家1初始手牌、點數、金錢並下注，需檢查下注金額不能為0、金錢不足與格式檢查
                //    手牌花色：Spade, Heart, Diamond, Club
                //    手牌點數：1~13
                //    手牌顯示格式: "花色 點數"
                Random myObject = new Random();
                //找到對應的手排花色與號碼

                String [] flower = { "Spade", "Heart", "Diamond", "Club" };
                String [] number = { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K" };
                card[] player1_array = new card[2];
                do {
                    int randflower = myObject.Next(0, 3);
                    int randnum = myObject.Next(0, 12);
                    player1_array[0].flower = flower[randflower];
                    player1_array[0].num = number[randnum];
                    randnum = myObject.Next(0, 12);
                    player1_array[1].flower = flower[randflower];
                    player1_array[1].num = number[randnum];
                } while ((player1_array[0].flower == player1_array[1].flower)&&(player1_array[0].num==player1_array[1].num));
                Console.WriteLine("玩家1手牌: {0} {1}, {2} {3}", player1_array[0].flower, player1_array[0].num, player1_array[1].flower, player1_array[1].num);

                int player1_point = Count_point(player1_array);



                Console.WriteLine("玩家1目前點數:{0}",player1_point);
                Console.WriteLine("玩家1目前金錢:{0}", player1_money);

                bool OK = true;
                int player1_putmoney;
                do
                {
                    Console.Write("請輸入下注金額: ");
                    player1_putmoney = int.Parse(Console.ReadLine());
                    //    金錢不足：Console.WriteLine("金錢不足，請重新輸入!");、並重新輸入
                    if (player1_putmoney > player1_money)
                    {
                        Console.WriteLine("金錢不足，請重新輸入!");
                        OK = false;
                    }
                    //    下注金額0：Console.WriteLine("金錢不能為零，請重新輸入!");、並重新輸入
                    else if (player1_putmoney == 0)
                    {
                        Console.WriteLine("金錢不能為零，請重新輸入!");
                        OK = false;
                    }
                    else
                    {
                        OK = true;
                    }
                } while (OK == false);
                //
                // 3. 顯示玩家2初始手牌、點數、金錢並下注，需檢查下注金額不能為0、金錢不足與格式檢查
                card[] player2_array = new card[2];
                do
                {
                    int randflower = myObject.Next(0, 3);
                    int randnum = myObject.Next(0, 12);
                    player2_array[0].flower = flower[randflower];
                    player2_array[0].num = number[randnum];
                    randnum = myObject.Next(0, 12);
                    player2_array[1].flower = flower[randflower];
                    player2_array[1].num = number[randnum];
                } while ((player2_array[0].flower == player2_array[1].flower) && (player2_array[0].num == player2_array[1].num));
                Console.WriteLine("玩家2手牌: {0} {1}, {2} {3}", player2_array[0].flower, player2_array[0].num, player2_array[1].flower, player2_array[1].num);

                int player2_point = Count_point(player2_array);

                Console.WriteLine("玩家2目前點數:{0}", player1_point);
                Console.WriteLine("玩家2目前金錢:{0}", player1_money);

                int player2_putmoney;
                OK = true;
                do
                {
                    Console.Write("請輸入下注金額: ");
                    player2_putmoney = int.Parse(Console.ReadLine());
                    //    金錢不足：Console.WriteLine("金錢不足，請重新輸入!");、並重新輸入
                    if (player2_putmoney > player2_money)
                    {
                        Console.WriteLine("金錢不足，請重新輸入!");
                        OK = false;
                    }
                    //    下注金額0：Console.WriteLine("金錢不能為零，請重新輸入!");、並重新輸入
                    else if (player2_putmoney == 0)
                    {
                        Console.WriteLine("金錢不能為零，請重新輸入!");
                        OK = false;
                    }
                    else
                    {
                        OK = true;
                    }
                } while (OK == false);
                //
                // 4. 兩位玩家依序行動(不斷抽牌或停止抽牌)
                //    注意1：抽牌完要顯示玩家手牌與點數
                //    注意2：選擇停止抽牌，需印出當前點數
                int turn = 1;
                while (true) {
                    Console.WriteLine("玩家{0}行動(輸入1抽1張排、輸入P停止抽牌):", turn);
                    String input1 = Console.ReadLine();

                    if (input1 == "1")
                    {
                        if (turn == 1) { 
                  
                            
                            Array.Resize(ref player1_array, (player1_array.Length) + 1);
                            do
                            {
                                int randflower = myObject.Next(0, 3);
                                int randnum = myObject.Next(0, 12);
                                player1_array[player1_array.Length-1].flower = flower[randflower];
                                player1_array[player1_array.Length - 1].num = number[randnum];
                            } while ((player1_array[player1_array.Length - 1].flower == player1_array[1].flower) && (player1_array[player1_array.Length - 1].num == player1_array[1].num));

                            Console.WriteLine("玩家{0}手牌:",turn);
                            for (int i = 0; i < player1_array.Length; i++)
                            {
                                Console.(" {0} {1},", turn, player1_array[i].flower, player1_array[i].num);
                            }
                            player1_point = Count_point(player1_array);
                            Console.WriteLine("玩家{0}目前點數:{1}", turn, player1_point);
                        }
                        else
                        {
                            Array.Resize(ref player2_array, (player2_array.Length) + 1);
                            do
                            {
                                int randflower = myObject.Next(0, 3);
                                int randnum = myObject.Next(0, 12);
                                player2_array[player2_array.Length - 1].flower = flower[randflower];
                                player2_array[player2_array.Length - 1].num = number[randnum];
                            } while ((player2_array[player2_array.Length - 1].flower == player2_array[1].flower) && (player2_array[player2_array.Length - 1].num == player2_array[1].num));
                            Console.WriteLine("玩家{0}手牌:", turn);
                            for (int i = 0; i < player1_array.Length; i++)
                            {
                                Console.(" {0} {1},", turn, player2_array[i].flower, player2_array[i].num);
                            }
                            player1_point = Count_point(player2_array);
                            Console.WriteLine("玩家{0}目前點數:{1}", turn, player2_point);
                        }


                        if ((player1_point > 21) || (player2_point > 21))
                        {
                            break;
                        }
                    }
                    else
                    {
                        if (turn == 1)
                        {
                            Console.WriteLine("玩家{0}跳過，目前點數: ", turn + player1_point);
                        }
                        else
                        {
                            Console.WriteLine("玩家{0}跳過，目前點數: ", turn + player2_point);
                        }
                        break;
                    }
                    //
                    // 5. 結果判定
                    //    case1 : 玩家1在抽牌時超過21點，直接判定玩家2獲勝(跳過玩家2行動)
                    //            Console.WriteLine("玩家1爆了，玩家2獲勝!");
                    if ((player1_point > 21))
                    {
                        Console.WriteLine("玩家1爆了，玩家2獲勝!");
                    }

                    //    case2 : 玩家2在抽牌時超過21點，直接判定玩家1獲勝
                    //            Console.WriteLine("玩家2爆了，玩家1獲勝!");
                    else if ((player2_point > 21))
                    {
                        Console.WriteLine("玩家2爆了，玩家1獲勝!");
                    }

                    //    case3 : 若雙方都沒超過21點，比較點數大小並判斷勝敗平手
                    else
                    {
                        if (player2_point > player1_point)
                        {
                            Console.WriteLine("玩家2獲勝，獲得{0}金錢",player1_putmoney);
                            player2_money += player1_putmoney;
                            player1_money -= player1_putmoney;
                        }
                        else if (player2_point < player1_point)
                        {
                            Console.WriteLine("玩家1獲勝，獲得{0}金錢", player2_putmoney);
                            player1_money += player2_putmoney;
                            player2_money -= player2_putmoney;
                        }
                        else
                        {
                            Console.WriteLine("平手!拿回各自的錢");
                        }
                    }

                    // 6. 如果雙方都還有錢就回到步驟2，否則結束程式
                    if (!((player1_money > 0) && (player2_money > 0)))
                    {
                        break;
                    }
                
                }
            }
            catch (FormatException)
            {
                Console.Write("請輸入正確格式");
                Console.ReadKey();
                return;
            }
            Console.ReadKey();
        }
        
    }
}
