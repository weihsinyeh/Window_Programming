﻿namespace WindowsFormsApp1
{


    partial class Database1DataSet
    {
    }
}
