﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week4_p1_template
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                // 程式流程
                // 1. 輸入玩家1、玩家2初始金錢(需要格式檢查)
                //
                //    Console.WriteLine("玩家1初始金錢: ");
                //    Console.WriteLine("玩家2初始金錢: ");
                // 2. 顯示玩家1初始手牌、點數、金錢並下注，需檢查下注金額不能為0、金錢不足與格式檢查
                //    手牌花色：Spade, Heart, Diamond, Club
                //    手牌點數：1~13
                //    手牌顯示格式: "花色 點數"
                //
                //    Console.WriteLine("玩家1手牌: " + [手牌1] + ", " + [手牌2]);
                //    Console.WriteLine("玩家1目前點數: " + [玩家1總點數]);
                //    Console.WriteLine("玩家1目前金錢: " + [玩家1金錢]);
                //    Console.Write("請輸入下注金額: ");
                //    金錢不足：Console.WriteLine("金錢不足，請重新輸入!");、並重新輸入
                //    下注金額0：Console.WriteLine("金錢不能為零，請重新輸入!");、並重新輸入
                //
                // 3. 顯示玩家2初始手牌、點數、金錢並下注，需檢查下注金額不能為0、金錢不足與格式檢查
                //
                //    Console.WriteLine("玩家2手牌: " + [手牌1] + ", " + [手牌2]);
                //    Console.WriteLine("玩家2目前點數: " + [玩家2總點數]);
                //    Console.WriteLine("玩家2目前金錢: " + [玩家2金錢]);
                //
                // 4. 兩位玩家依序行動(不斷抽牌或停止抽牌)
                //    注意1：抽牌完要顯示玩家手牌與點數
                //    注意2：選擇停止抽牌，需印出當前點數
                //
                //    while (true) 
                //        Console.WriteLine("玩家1/2行動(輸入1抽1張排、輸入P停止抽牌):");
                //        if 輸入 1:
                //            Console.WriteLine("玩家1/2手牌: " + [手牌1] + ", " + [手牌2] + ", " + ....);
                //            Console.WriteLine("玩家1/2目前點數: " + [玩家1/2總點數]);
                //            if 超過21點:
                //                break
                //            else
                //                continue
                //        else if 輸入 P:
                //            停止抽牌：Console.WriteLine("玩家1/2跳過，目前點數: " + [玩家總點數]);
                //            break
                //
                // 5. 結果判定
                //    case1 : 玩家1在抽牌時超過21點，直接判定玩家2獲勝(跳過玩家2行動)
                //            Console.WriteLine("玩家1爆了，玩家2獲勝!");
                //    case2 : 玩家2在抽牌時超過21點，直接判定玩家1獲勝
                //            Console.WriteLine("玩家2爆了，玩家1獲勝!");
                //    case3 : 若雙方都沒超過21點，比較點數大小並判斷勝敗平手
                //
                //    玩家1/2獲勝：Console.WriteLine("玩家1/2獲勝，獲得" + [玩家2/1下注金錢] + "金錢");
                //    平手：Console.WriteLine("平手!拿回各自的錢");
                //
                // 6. 如果雙方都還有錢就回到步驟2，否則結束程式
                //
                // 格式檢查錯誤：Console.WriteLine("請輸入正確格式");、並直接結束程式
            }
            catch (FormatException)
            {

            }
            Console.ReadKey();
        }
    }
}
